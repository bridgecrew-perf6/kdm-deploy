--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2 (Ubuntu 14.2-1.pgdg20.04+1+b1)
-- Dumped by pg_dump version 14.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE d80d4ofdolsje4;
--
-- Name: d80d4ofdolsje4; Type: DATABASE; Schema: -; Owner: lcpnrkbloohwdq
--

CREATE DATABASE d80d4ofdolsje4 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE d80d4ofdolsje4 OWNER TO lcpnrkbloohwdq;

\connect d80d4ofdolsje4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: lcpnrkbloohwdq
--

COPY public.alembic_version (version_num) FROM stdin;
\.
COPY public.alembic_version (version_num) FROM '$$PATH$$/4381.dat';

--
-- Data for Name: lab_report; Type: TABLE DATA; Schema: public; Owner: lcpnrkbloohwdq
--

COPY public.lab_report (id, created_time, updated_time, patient_id, doctor_name, sample_type, patient_type, test_date, created_user_id, updated_user_id, sample_id) FROM stdin;
\.
COPY public.lab_report (id, created_time, updated_time, patient_id, doctor_name, sample_type, patient_type, test_date, created_user_id, updated_user_id, sample_id) FROM '$$PATH$$/4383.dat';

--
-- Data for Name: lab_result; Type: TABLE DATA; Schema: public; Owner: lcpnrkbloohwdq
--

COPY public.lab_result (id, created_time, updated_time, lab_report_id, parameter_name, test_name, parameter_id, unit, result, upper_limit, lower_limit, remark, created_user_id, updated_user_id) FROM stdin;
\.
COPY public.lab_result (id, created_time, updated_time, lab_report_id, parameter_name, test_name, parameter_id, unit, result, upper_limit, lower_limit, remark, created_user_id, updated_user_id) FROM '$$PATH$$/4391.dat';

--
-- Data for Name: test_category; Type: TABLE DATA; Schema: public; Owner: lcpnrkbloohwdq
--

COPY public.test_category (id, created_time, updated_time, name, created_user_id, updated_user_id) FROM stdin;
\.
COPY public.test_category (id, created_time, updated_time, name, created_user_id, updated_user_id) FROM '$$PATH$$/4387.dat';

--
-- Data for Name: lab_test; Type: TABLE DATA; Schema: public; Owner: lcpnrkbloohwdq
--

COPY public.lab_test (id, created_time, updated_time, name, test_category_id, created_user_id, updated_user_id) FROM stdin;
\.
COPY public.lab_test (id, created_time, updated_time, name, test_category_id, created_user_id, updated_user_id) FROM '$$PATH$$/4393.dat';

--
-- Data for Name: parameter; Type: TABLE DATA; Schema: public; Owner: lcpnrkbloohwdq
--

COPY public.parameter (id, created_time, updated_time, name, unit, lab_test_id, result_type, result_default_text, created_user_id, updated_user_id) FROM stdin;
\.
COPY public.parameter (id, created_time, updated_time, name, unit, lab_test_id, result_type, result_default_text, created_user_id, updated_user_id) FROM '$$PATH$$/4395.dat';

--
-- Data for Name: parameter_range; Type: TABLE DATA; Schema: public; Owner: lcpnrkbloohwdq
--

COPY public.parameter_range (id, created_time, updated_time, parameter_id, upper_limit, lower_limit, low_remark, high_remark, normal_remark, created_user_id, updated_user_id) FROM stdin;
\.
COPY public.parameter_range (id, created_time, updated_time, parameter_id, upper_limit, lower_limit, low_remark, high_remark, normal_remark, created_user_id, updated_user_id) FROM '$$PATH$$/4397.dat';

--
-- Data for Name: patient; Type: TABLE DATA; Schema: public; Owner: lcpnrkbloohwdq
--

COPY public.patient (id, created_time, updated_time, name, gender, date_of_birth, age, address, contact_details, created_user_id, updated_user_id) FROM stdin;
\.
COPY public.patient (id, created_time, updated_time, name, gender, date_of_birth, age, address, contact_details, created_user_id, updated_user_id) FROM '$$PATH$$/4385.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: lcpnrkbloohwdq
--

COPY public."user" (id, username, password, role) FROM stdin;
\.
COPY public."user" (id, username, password, role) FROM '$$PATH$$/4389.dat';

--
-- Name: lab_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lcpnrkbloohwdq
--

SELECT pg_catalog.setval('public.lab_report_id_seq', 4, true);


--
-- Name: lab_result_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lcpnrkbloohwdq
--

SELECT pg_catalog.setval('public.lab_result_id_seq', 8, true);


--
-- Name: lab_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lcpnrkbloohwdq
--

SELECT pg_catalog.setval('public.lab_test_id_seq', 94, true);


--
-- Name: parameter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lcpnrkbloohwdq
--

SELECT pg_catalog.setval('public.parameter_id_seq', 115, true);


--
-- Name: parameter_range_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lcpnrkbloohwdq
--

SELECT pg_catalog.setval('public.parameter_range_id_seq', 71, true);


--
-- Name: patient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lcpnrkbloohwdq
--

SELECT pg_catalog.setval('public.patient_id_seq', 3, true);


--
-- Name: test_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lcpnrkbloohwdq
--

SELECT pg_catalog.setval('public.test_category_id_seq', 18, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lcpnrkbloohwdq
--

SELECT pg_catalog.setval('public.user_id_seq', 3, true);


--
-- PostgreSQL database dump complete
--

